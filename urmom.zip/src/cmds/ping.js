const Discord = require('discord.js');
const client = new Discord.Client();

client.on('ready', () => {
	console.log(`Logged in as ${client.user.tag}!`);
});

client.on('interactionCreate', async interaction => {
	if (!interaction.isCommand()) return;
	if (interaction.commandName === 't!!ping') {
		new Discord.MessageEmbed(data);
    .setTitle(🏓 Pong!)
    .setFooter(Pong! :))
    .setDescription(Woah! Ping Pong! C:)

	}
});

client.login('ODY3MjkwODgzNjY5NjIyODA0.YPe9lA.rZzrAE-rttS67_Jc-V9ciYkihfo');